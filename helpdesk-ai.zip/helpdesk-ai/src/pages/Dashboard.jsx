import React, { useMemo } from "react";

import {
  Box,
  Paper,
  Typography
} from "@mui/material";

import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  CartesianGrid,
  XAxis,
  YAxis
} from "recharts";

import StatsCard from "../components/StatsCard";

import ConfirmationNumberIcon from "@mui/icons-material/ConfirmationNumber";
import CompareArrowsIcon from "@mui/icons-material/CompareArrows";
import VerifiedIcon from "@mui/icons-material/Verified";
import HourglassTopIcon from "@mui/icons-material/HourglassTop";
import ReportProblemIcon from "@mui/icons-material/ReportProblem";
import PsychologyIcon from "@mui/icons-material/Psychology";

export default function Dashboard({
  analysisData = []
}) {

  const metrics = useMemo(() => {

    const totalTickets =
      analysisData.length;
  
    const resolved =
      analysisData.filter(
        x =>
          x.ai_resolution_status ===
          "Resolved"
      ).length;

    const pending =
      analysisData.filter(
        x =>
          x.ai_resolution_status ===
          "Partially Resolved"
      ).length;

    const unresolved =
      analysisData.filter(
        x =>
          x.ai_resolution_status ===
          "Unresolved"
      ).length;

    const matched =
      analysisData.filter(
        x =>
          x.issue_match &&
          x.resolution_match
      ).length;

    const mismatched =
      totalTickets - matched;

    const positiveSentiment =
      analysisData.filter(
        x =>
          x.sentiment ===
          "Positive"
      ).length;

    const sentimentScore =
      totalTickets
        ? Math.round(
            (positiveSentiment /
              totalTickets) *
              100
          )
        : 0;

    const matchPercentage =
      totalTickets
        ? Math.round(
            (matched /
              totalTickets) *
              100
          )
        : 0;

    return {
      totalTickets,
      resolved,
      pending,
      unresolved,
      matched,
      mismatched,
      sentimentScore,
      matchPercentage
    };

  }, [analysisData]);

  const cards = [
    {
      title: "Tickets Analyzed",
      value: metrics.totalTickets,
      icon: (
        <ConfirmationNumberIcon fontSize="large" />
      ),
      iconColor: "#1976d2",
      footer: "Analyzed tickets"
    },

    {
      title: "AI-Agent Match %",
      value: `${metrics.matchPercentage}%`,
      icon: (
        <CompareArrowsIcon fontSize="large" />
      ),
      iconColor: "#4caf50",
      footer: "Status alignment"
    },

     {
      title: "Positive Sentiment",
      value: `${metrics.sentimentScore}%`,
      icon: (
        <PsychologyIcon fontSize="large" />
      ),
      iconColor: "#8e24aa",
      footer: "Customer sentiment"
    },

    {
      title: "Resolved",
      value: metrics.resolved,
      icon: (
        <VerifiedIcon fontSize="large" />
      ),
      iconColor: "#2e7d32",
      footer: "Resolved tickets"
    },

    {
      title: "Partially Resolved",
      value: metrics.pending,
      icon: (
        <HourglassTopIcon fontSize="large" />
      ),
      iconColor: "#fb8c00",
      footer: "Pending tickets"
    },

    {
      title: "Unresolved",
      value: metrics.unresolved,
      icon: (
        <ReportProblemIcon fontSize="large" />
      ),
      iconColor: "#e53935",
      footer: "Need review"
    },

   
  ];

  const comparisonChart = {
    title:
      "AI vs Agent Agreement",

    donutData: [
      {
        name: "Matched",
        value: metrics.matched
      },
      {
        name: "Mismatch",
        value: metrics.mismatched
      }
    ],

    colors: [
      "#4CAF50",
      "#F44336"
    ]
  };

  const resolutionChart = {
    title:
      "Resolution Status",

    donutData: [
      {
        name: "Resolved",
        value: metrics.resolved
      },
      {
        name: "Pending",
        value: metrics.pending
      },
      {
        name: "Unresolved",
        value: metrics.unresolved
      }
    ],

    colors: [
      "#4CAF50",
      "#FB8C00",
      "#F44336"
    ]
  };

  const categoryDistribution =
    Object.values(
      analysisData.reduce(
        (acc, item) => {

          acc[item.category] =
            acc[item.category] || {
              category:
                item.category,
              count: 0
            };

          acc[item.category]
            .count += 1;

          return acc;
        },
        {}
      )
    );

  const intentDistribution =
    Object.values(
      analysisData.reduce(
        (acc, item) => {

          (item.intent || []).forEach(
            intent => {

              acc[intent] =
                acc[intent] || {
                  intent,
                  count: 0
                };

              acc[intent]
                .count += 1;

            }
          );

          return acc;
        },
        {}
      )
    );

  const PieChartCard = ({
    chart
  }) => (
    <Paper
      sx={{
        p: 3,
        borderRadius: 4
      }}
    >
      <Typography
        variant="h6"
        fontWeight={700}
        mb={2}
      >
        {chart.title}
      </Typography>

      <ResponsiveContainer
        width="100%"
        height={300}
      >
        <PieChart>
          <Pie
            data={chart.donutData}
            dataKey="value"
            nameKey="name"
            outerRadius={90}
            labelLine={false}
          >
            {chart.donutData.map(
              (
                entry,
                index
              ) => (
                <Cell
                  key={index}
                  fill={
                    chart.colors[
                      index
                    ]
                  }
                />
              )
            )}
          </Pie>

          <Tooltip />
          <Legend />
        </PieChart>
      </ResponsiveContainer>
    </Paper>
  );

  return (
    <Box>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns:
            "repeat(auto-fit,minmax(220px,1fr))",
          gap: 3,
          mb: 4
        }}
      >
        {cards.map(card => (
          <StatsCard
            key={
              card.title
            }
            {...card}
          />
        ))}
      </Box>

      {/* Category Distribution */}

      <Paper
        sx={{
          p: 3,
          borderRadius: 4,
          mb: 4
        }}
      >
        <Typography
          variant="h6"
          fontWeight={700}
          mb={3}
        >
          Ticket Category Distribution
        </Typography>

        <ResponsiveContainer
          width="100%"
          height={350}
        >
          <BarChart
            data={
              categoryDistribution
            }
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="category" />
            <YAxis allowDecimals={false}/>
            <Tooltip />

            <Bar
            
              dataKey="count"
              fill="#022d58"
              radius={[
                8,
                8,
                0,
                0
              ]}
            />
          </BarChart>
        </ResponsiveContainer>
      </Paper>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            md: "1fr 1fr"
          },
          gap: 3,
          mb: 4
        }}
      >
        <PieChartCard
          chart={
            comparisonChart
          }
        />

        <PieChartCard
          chart={
            resolutionChart
          }
        />
      </Box>

      <Paper
        sx={{
          p: 3,
          borderRadius: 4
        }}
      >
        <Typography
          variant="h6"
          fontWeight={700}
          mb={3}
        >
          Intent Distribution
        </Typography>

        <ResponsiveContainer
          width="100%"
          height={350}
        >
          <BarChart
            data={
              intentDistribution
            }
          >
            <CartesianGrid strokeDasharray="3 3" />

            <XAxis dataKey="intent"
           interval={0}
            angle={-30}
            textAnchor="end"
            height={100}
            tick={{ fontSize: 12}}
            tickFormatter={(value) =>
            value.length > 10
            ? `${value.substring(0, 10)}...`
            : value
            }
            />

            <YAxis allowDecimals={false} />

            <Tooltip />

            <Bar
              dataKey="count"
              fill="#7B1FA2"
              radius={[
                8,
                8,
                0,
                0
              ]}
            />
          </BarChart>
        </ResponsiveContainer>
      </Paper>

    </Box>
  );
}