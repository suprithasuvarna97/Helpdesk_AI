import React, { useEffect, useState } from "react";
import {
  Box,
  Typography,
  Paper,
  Table,
  TableHead,
  TableBody,
  TableRow,
  TableCell,
  TableContainer,
  Chip,
  CircularProgress,
  Alert,
  FormControl,
  InputLabel,
  Select,
  MenuItem
} from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import IconButton from "@mui/material/IconButton";
import Tooltip from "@mui/material/Tooltip";

import WarningAmberIcon from "@mui/icons-material/WarningAmber";
import DescriptionIcon from "@mui/icons-material/Description";

import { API_BASE_URL } from "../config";
import Pagination from "@mui/material/Pagination";

export default function UnprocessedFiles() {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
const [page, setPage] = useState(0);
const [rowsPerPage, setRowsPerPage] = useState(20);
const [totalCount, setTotalCount] = useState(0);

  useEffect(() => {
    loadFailedFiles();
  }, [page, rowsPerPage]);

  const loadFailedFiles = async () => {
    try {
      const offset = page * rowsPerPage;
      const response = await fetch(
        //`${API_BASE_URL}/logs`
       `${API_BASE_URL}/logs?limit=${rowsPerPage}&offset=${offset}`
      );

      const data = await response.json();

      setFiles(data.logs || []);
      setTotalCount(data.total_rows || 0);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (id) => {
  if (
    !window.confirm(
      "Are you sure you want to delete this log?"
    )
  ) {
    return;
  }

  try {
    const response = await fetch(
      `${API_BASE_URL}/delete-logs/${id}`,
      {
        method: "DELETE",
      }
    );

    const data = await response.json();
    console.log("hereee",data)
    if (data.success) {
      // setFiles((prev) =>
      //   prev.filter((item) => item.id !== id)
      // );
      // alert("File Deleted Successfully");
      alert("File Deleted Successfully");
      loadFailedFiles();
    } else {
      alert(data.message || "Delete failed");
    }
  } catch (error) {
    console.error(error);
    alert("Delete failed");
  }
};

  if (loading) {
    return (
      <Box
        sx={{
          height: "60vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Box>
      {/* Header */}

      <Paper
        elevation={3}
        sx={{
          p: 3,
          mb: 3,
          borderRadius: 3,
          background:
            "linear-gradient(135deg,#c62828,#ef5350)",
          color: "white",
        }}
      >
        <Typography
          variant="h5"
          fontWeight={700}
        >
          Unprocessed / Failed Files
        </Typography>

        <Typography sx={{ mt: 1 }}>
          Files that could not be processed
          successfully by the system.
        </Typography>

        <Typography
          sx={{
            mt: 2,
            fontWeight: 600,
          }}
        >
          Total Files : {totalCount}
        </Typography>
      </Paper>

      {/* Empty State */}

      {files.length === 0 ? (
        <Alert severity="success">
          No failed files found.
        </Alert>
      ) : (
        <TableContainer
          component={Paper}
          elevation={3}
          sx={{ borderRadius: 3 }}
        >
          <Table>
            <TableHead>
              <TableRow
                sx={{
                  bgcolor: "#f5f5f5",
                }}
              >
                <TableCell>
                  <b>File ID</b>
                </TableCell>

                <TableCell>
                  <b>File Name</b>
                </TableCell>

                <TableCell>
                  <b>Status</b>
                </TableCell>

                <TableCell>
                  <b>Error Message</b>
                </TableCell>

                <TableCell>
                  <b>Created</b>
                </TableCell>

                <TableCell align="center">
                  <b>Delete</b>
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>
              {files.map((file, index) => (
                <TableRow
                  key={file.id || index}
                  hover
                >
                  <TableCell>
                    <Typography
                      fontFamily="monospace"
                      fontSize={12}
                    >
                      {file.file_id ||
                        file.id ||
                        "-"}
                    </Typography>
                  </TableCell>

                  <TableCell>
                    <Box
                      display="flex"
                      alignItems="center"
                      gap={1}
                    >
                     
                      <Typography
                        fontWeight={600}
                      >
                        {file.file_name ||
                          "-"}
                      </Typography>
                    </Box>
                  </TableCell>

                  <TableCell>
                    <Chip
                      icon={
                        <WarningAmberIcon />
                      }
                      label="FAILED"
                      color="error"
                      size="small"
                    />
                  </TableCell>

                  <TableCell>
                    <Typography
                      color="error.main"
                      fontSize={13}
                    >
                      {file.error_message ||
                        file.message ||
                        "-"}
                    </Typography>
                  </TableCell>

                  <TableCell>
                    {file.created_at || "-"}
                  </TableCell>
                  <TableCell align="center">
                  <Tooltip title="Delete Log">
                    <IconButton
                      color="error"
                      onClick={() =>
                        handleDelete(file.id)
                      }
                    >
                      <DeleteIcon />
                    </IconButton>
                  </Tooltip>
                </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    <Box
  sx={{
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    mt: 3,
    p: 2,
  }}
>
  <Typography variant="body2">
    Showing {(page * rowsPerPage) + 1} -
    {Math.min(
      (page + 1) * rowsPerPage,
      totalCount
    )} of {totalCount} files
  </Typography>

  <Box
    sx={{
      display: "flex",
      alignItems: "center",
      gap: 2,
    }}
  >
   

    <Pagination
      page={page + 1}
      count={Math.ceil(totalCount / rowsPerPage)}
      color="primary"
      shape="rounded"
      onChange={(e, value) => {
        setPage(value - 1);
      }}
    />
     <FormControl size="small">
      <InputLabel>Rows</InputLabel>
      <Select
        value={rowsPerPage}
        label="Rows"
        onChange={(e) => {
          setRowsPerPage(Number(e.target.value));
          setPage(0);
        }}
      >
        <MenuItem value={5}>5</MenuItem>
        <MenuItem value={10}>10</MenuItem>
        <MenuItem value={20}>20</MenuItem>
        <MenuItem value={50}>50</MenuItem>
        <MenuItem value={100}>100</MenuItem>
      </Select>
    </FormControl>
  </Box>
</Box>
      
    </Box>
  );
}