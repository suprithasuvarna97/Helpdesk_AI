import React, { useMemo } from "react";

import {
  Box,
  Typography,
  Paper,
  Avatar,
  Chip,
  LinearProgress
} from "@mui/material";

import WorkspacePremiumIcon from "@mui/icons-material/WorkspacePremium";
import PersonIcon from "@mui/icons-material/Person";

export default function SupportAgentList({
  analysisData = []
}) {

  const agentData = useMemo(() => {

    const grouped = {};

    analysisData.forEach((row) => {

      const key = row.user_id;

      if (!grouped[key]) {

        grouped[key] = {
          user_id: row.user_id,
          user_name: row.user_name,

          totalTickets: 0,
          resolved: 0,
          partiallyResolved: 0,
          unresolved: 0,

          issueMatch: 0,
          resolutionMatch: 0
        };
      }

      grouped[key].totalTickets++;

      if (
        row.ai_resolution_status ===
        "Resolved"
      ) {
        grouped[key].resolved++;
      }
      else if (
        row.issue_match &&
        !row.resolution_match
      ) {
        grouped[key]
          .partiallyResolved++;
      }
      else {
        grouped[key].unresolved++;
      }

      if (row.issue_match) {
        grouped[key].issueMatch++;
      }

      if (row.resolution_match) {
        grouped[key].resolutionMatch++;
      }

    });

    return Object.values(grouped)
      .map((agent) => {

        const issueMatchPercentage =
          Math.round(
            (agent.issueMatch /
              agent.totalTickets) *
            100
          );

        const resolutionMatchPercentage =
          Math.round(
            (agent.resolutionMatch /
              agent.totalTickets) *
            100
          );

        const score = Math.round(resolutionMatchPercentage
          // (issueMatchPercentage * 0.4) +
          // (resolutionMatchPercentage * 0.6)
        );

        return {
          ...agent,
          score,
          issueMatchPercentage,
          resolutionMatchPercentage
        };
      })
      .sort(
        (a, b) => b.score - a.score
      );

  }, [analysisData]);

  const getScoreColor = (score) => {
    if (score >= 90) return "#2e7d32";
    if (score >= 75) return "#ed6c02";
    return "#d32f2f";
  };

  return (
    <Box width="100%">

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            md: "repeat(3, minmax(0,1fr))"
          },
          gap: 3,
          width: "100%"
        }}
      >

        {agentData.map(
          (agent, index) => (

            <Paper
              key={agent.user_id}
              elevation={3}
              sx={{
                borderRadius: 4,
                overflow: "hidden",
                transition: "0.25s",

                "&:hover": {
                  transform:
                    "translateY(-4px)",
                  boxShadow: 8
                }
              }}
            >

              {/* HEADER */}

              <Box
                sx={{
                  p: 2.5,
                  background:
                    "linear-gradient(135deg,#022d58,#022d58)",
                  color: "#fff"
                }}
              >

                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                >

                  <Box
                    display="flex"
                    alignItems="center"
                    gap={1.5}
                  >

                    <Avatar
                      sx={{
                        bgcolor:
                          "rgba(255,255,255,.25)"
                      }}
                    >
                      <PersonIcon />
                    </Avatar>

                    <Box>

                      <Typography
                        fontWeight={700}
                      >
                        {agent.user_name}
                      </Typography>

                      <Typography
                        variant="caption"
                      >
                        {agent.user_id}
                      </Typography>

                    </Box>

                  </Box>

                  <Chip
                    icon={<WorkspacePremiumIcon />}
                    label={`#${index + 1}`}
                    size="small"
                    sx={{
                      bgcolor: "#fff",
                      fontWeight: 600
                    }}
                  />

                </Box>

              </Box>

              {/* BODY */}

              <Box p={2.5}>

                {/* SCORE */}

                <Box mb={2}>

                  <Box
                    display="flex"
                    justifyContent="space-between"
                    mb={1}
                  >
                    <Typography
                      fontWeight={600}
                    >
                      {/* Performance Score */}
                    </Typography>

                    <Typography
                      fontWeight={700}
                      color={getScoreColor(
                        agent.score
                      )}
                    >
                      {agent.score}%
                    </Typography>
                  </Box>

                  <LinearProgress
                    variant="determinate"
                    value={agent.score}
                    sx={{
                      height: 10,
                      borderRadius: 10
                    }}
                  />

                </Box>

                {/* KPI GRID */}

                <Box
                  sx={{
                    display: "grid",
                    gridTemplateColumns:
                      "repeat(2,1fr)",
                    gap: 1.2
                  }}
                >

                  <MetricCard
                    title="Total Tickets"
                    value={agent.totalTickets}
                  />

                  <MetricCard
                    title="Resolved"
                    value={agent.resolved}
                    color="#2e7d32"
                  />

                  <MetricCard
                    title="Partial"
                    value={
                      agent.partiallyResolved
                    }
                    color="#ed6c02"
                  />

                  <MetricCard
                    title="Unresolved"
                    value={agent.unresolved}
                    color="#d32f2f"
                  />

                  {/* <MetricCard
                    title="Issue Match"
                    value={`${agent.issueMatchPercentage}%`}
                    color="#1976d2"
                  /> */}

                  <MetricCard
                 
                    title="Resolution Match"
                    value={`${agent.resolutionMatchPercentage}%`}
                    color="#7b1fa2"
                  />

                </Box>

              </Box>

            </Paper>

          )
        )}

      </Box>

    </Box>
  );
}

function MetricCard({
  title,
  value,
  color
}) {
  return (
    <Box
      sx={{
        p: 1.25,
        border:
          "1px solid #e5e7eb",
        borderRadius: 2,
        bgcolor: "#fafafa"
      }}
    >

      <Typography
        variant="caption"
        color="text.secondary"
      >
        {title}
      </Typography>

      <Typography
        fontWeight={700}
        sx={{
          color: color || "inherit",
          mt: 0.5
        }}
      >
        {value}
      </Typography>

    </Box>
  );
}