import React, { useState } from "react";

import {
  Box,
  Tabs,
  Tab,
  Paper,
  Typography,
  Table,
  TableHead,
  TableBody,
  TableCell,
  TableRow,
  TableContainer,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Chip,
  Avatar,
  Alert,
  Divider,
  Stack
} from "@mui/material";

import PersonIcon from "@mui/icons-material/Person";

import SupportAgentIcon from "@mui/icons-material/SupportAgent";

export default function AnalyticsTables({
  analysisData = []
}) {
  const [tab, setTab] = useState(0);

  const [selectedTicket, setSelectedTicket] =
    useState(null);

  const [openDialog, setOpenDialog] =
    useState(false);
  const [openReviewDialog, setOpenReviewDialog] =useState(false);

  const safeData = Array.isArray(
    analysisData
  )
    ? analysisData
    : [];

 const conversationData =
  selectedTicket?.conversation
    ?.split("\n")
    ?.filter((line) => line.trim())
    ?.map((line) => {
      const role = line.startsWith("Agent:")
        ? "Agent"
        : "User";

      return {
        role,
        message: line.replace(
          /^(Agent:|User:)\s*/,
          ""
        )
      };
    }) || [];



  return (
    <Box>
      <Tabs
        value={tab}
        onChange={(e, value) =>
          setTab(value)
        }
        sx={{
          mb: 3,
          "& .MuiTab-root": {
            fontWeight: 600
          }
        }}
      >
        <Tab label="AI Insights" />
        <Tab label="AI vs Agent Comparison" />
      </Tabs>

      {/* ============================ */}
      {/* TICKET ANALYSIS */}
      {/* ============================ */}

      {tab === 0 && (
        <TableContainer
          component={Paper}
          sx={{
            borderRadius: 4
          }}
        >
          <Table>

            <TableHead>
              <TableRow
                sx={{
                  bgcolor:
                    "background.default"
                }}
              >
                <TableCell>
                  Ticket No.
                </TableCell>

                <TableCell>
                  Category
                </TableCell>

                <TableCell>
                  Sub Category
                </TableCell>

                <TableCell>
                  Sentiment
                </TableCell>

                {/* <TableCell>
                  AI Issue Status
                </TableCell> */}

                <TableCell>
                  AI Resolution Status
                </TableCell>

                <TableCell>
                  Intent
                </TableCell>

                <TableCell align="center">
                  Action
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>

              {safeData.map((row) => (

                <TableRow
                  hover
                  key={row.ims_id}
                >

                  <TableCell>
                    {row.ims_id}
                  </TableCell>

                  <TableCell>

                    <Chip
                      label={row.category}
                      color="primary"
                      size="small"
                    />

                  </TableCell>

                  <TableCell>
                    {row.sub_category}
                  </TableCell>

                  <TableCell>

                    <Chip
                      label={row.sentiment}
                      color={
                        row.sentiment ===
                        "Positive"
                          ? "success"
                          : row.sentiment ===
                            "Neutral"
                          ? "warning"
                          : "error"
                      }
                      size="small"
                    />

                  </TableCell>

                  {/* <TableCell>

                    <Chip
                      label={
                        row.ai_issue_status
                      }
                      color={
                        row.ai_issue_status ===
                        "Closed"
                          ? "success"
                          : "warning"
                      }
                      size="small"
                    />

                  </TableCell> */}

                  <TableCell>

                    <Chip
                      label={
                        row.ai_resolution_status
                      }
                      color={
                        row.ai_resolution_status ===
                        "Resolved"
                          ? "success"
                          : row.ai_resolution_status ===
                            "Pending"
                          ? "warning"
                          : "error"
                      }
                      size="small"
                    />

                  </TableCell>

                  <TableCell
                    sx={{
                      maxWidth: 250
                    }}
                  >
                    {row.intent?.join(", ")}
                  </TableCell>

                  <TableCell
                    align="center"
                  >
                    <Button
                      variant="contained"
                      size="small"
                      onClick={() => {
                        setSelectedTicket(
                          row
                        );
                        setOpenDialog(
                          true
                        );
                      }}
                    >
                      View
                    </Button>
                  </TableCell>

                </TableRow>

              ))}

            </TableBody>

          </Table>
        </TableContainer>
      )}

      {/* ============================ */}
      {/* AI VS AGENT */}
      {/* ============================ */}

      {tab === 1 && (

        <TableContainer
          component={Paper}
          sx={{
            borderRadius: 4
          }}
        >
          <Table>

            <TableHead>
              <TableRow
                sx={{
                  bgcolor:
                    "background.default"
                }}
              >
                <TableCell>
                  Ticket No.
                </TableCell>

                {/* <TableCell>
                  Issue Status(Agent)
                </TableCell>

                <TableCell>
                 Issue Status(AI)
                </TableCell>

                <TableCell>
                  Issue Match
                </TableCell> */}

                <TableCell>
                 Resolution Status(Agent)
                </TableCell>

                <TableCell>
               Resolution Status(AI)
                </TableCell>

                <TableCell>
                  Resolution Match
                </TableCell>

                <TableCell>
                  Result
                </TableCell>
              </TableRow>
            </TableHead>

            <TableBody>

              {safeData.map((row) => {

                const match =
                  row.issue_match &&
                  row.resolution_match;

                return (

                  <TableRow
                    key={row.ims_id}
                    hover
                  >

                    <TableCell>
                      {row.ims_id}
                    </TableCell>

                    {/* <TableCell>
                      {
                        row.agent_issue_status
                      }
                    </TableCell>

                    <TableCell>
                      {
                        row.ai_issue_status
                      }
                    </TableCell>

                    <TableCell>

                      <Chip
                        label={
                          row.issue_match
                            ? "Matched"
                            : "Mismatch"
                        }
                        color={
                          row.issue_match
                            ? "success"
                            : "error"
                        }
                        size="small"
                      />

                    </TableCell> */}

                    <TableCell>
                      {
                        row.agent_resolution_status
                      }
                    </TableCell>

                    <TableCell>
                      {
                        row.ai_resolution_status
                      }
                    </TableCell>

                    <TableCell>

                      <Chip
                        label={
                          row.resolution_match
                            ? "Matched"
                            : "Mismatch"
                        }
                        color={
                          row.resolution_match
                            ? "success"
                            : "error"
                        }
                        size="small"
                      />

                    </TableCell>

                    {/* <TableCell>

                      <Chip
                        label={
                          match
                            ? "Aligned"
                            : "Review"
                        }
                        color={
                          match
                            ? "success"
                            : "warning"
                        }
                      />

                    </TableCell> */}
                    <TableCell>
                    {match ? (
                  <Chip
                    label="Aligned"
                    color="success"
                  />
                ) : (
                  <Button
                    variant="contained"
                    color="warning"
                    size="small"
                    onClick={() => {
                      setSelectedTicket(row);
                      setOpenReviewDialog(true);
                    }}
                  >
                    Review
                  </Button>
                )}</TableCell>

                  </TableRow>

                );
              })}

            </TableBody>

          </Table>
        </TableContainer>
      )}

      {/* ============================ */}
      {/* DETAILS DIALOG */}
      {/* ============================ */}

      <Dialog
        open={openDialog}
        onClose={() =>
          setOpenDialog(false)
        }
        maxWidth="md"
        fullWidth
      >
        <DialogTitle>
          Ticket Analysis Details
        </DialogTitle>

        <DialogContent>

          {selectedTicket && (

            <Box>

              <Typography
                variant="h6"
                mb={2}
              >
                Ticket No :
                {
                  selectedTicket.ims_id
                }
              </Typography>

              <Paper
                sx={{
                  p: 2,
                  mb: 2
                }}
              >
                <Typography
                  fontWeight={700}
                >
                  Category
                </Typography>

                <Typography>
                  {
                    selectedTicket.category
                  }
                </Typography>
              </Paper>

              <Paper
                sx={{
                  p: 2,
                  mb: 2
                }}
              >
                <Typography
                  fontWeight={700}
                >
                  Sub Category
                </Typography>

                <Typography>
                  {
                    selectedTicket.sub_category
                  }
                </Typography>
              </Paper>

              <Paper
                sx={{
                  p: 2,
                  mb: 2
                }}
              >
                <Typography
                  fontWeight={700}
                >
                  Intent
                </Typography>

                <Box mt={1}>
                  {selectedTicket.intent?.map(
                    (
                      item,
                      index
                    ) => (
                      <Chip
                        key={index}
                        label={item}
                        sx={{
                          mr: 1
                        }}
                      />
                    )
                  )}
                </Box>
              </Paper>

              <Paper
                sx={{
                  p: 2,
                  mb: 2
                }}
              >
                <Typography
                  fontWeight={700}
                >
                  Executive Summary
                </Typography>

                <Typography>
                  {
                    selectedTicket.executive_summary
                  }
                </Typography>
              </Paper>

              <Paper
                sx={{
                  p: 2,
                  mb: 2
                }}
              >
                <Typography
                  fontWeight={700}
                >
                  Sub Topics
                </Typography>

                <Typography>
                  {
                    selectedTicket.sub_topics
                  }
                </Typography>
              </Paper>

              <Paper
                sx={{
                  p: 2
                }}
              >
                <Typography
                  fontWeight={700}
                >
                  Follow Up Action
                </Typography>

                <Typography>
                  {
                    selectedTicket.followup_action
                  }
                </Typography>
              </Paper>

            </Box>

          )}

        </DialogContent>

        <DialogActions>

          <Button
            variant="contained"
            onClick={() =>
              setOpenDialog(false)
            }
          >
            Close
          </Button>

        </DialogActions>

      </Dialog>
      <Dialog
  open={openReviewDialog}
  onClose={() => setOpenReviewDialog(false)}
  maxWidth="md"
  fullWidth
>
  <DialogTitle>
    AI Review Analysis
  </DialogTitle>

  <DialogContent dividers>

    {selectedTicket && (
      <Box>

        {/* HEADER */}

        <Paper
          elevation={0}
          sx={{
            p: 2,
            mb: 3,
            border: "1px solid #e0e0e0",
            borderRadius: 3
          }}
        >
          <Typography
            variant="h6"
            fontWeight={700}
          >
            Ticket #{selectedTicket.ims_id}
          </Typography>

          <Typography
            color="text.secondary"
          >
            {selectedTicket.category}
          </Typography>
        </Paper>

        {/* AI REASON */}

        <Alert
          severity="warning"
          sx={{
            mb: 3,
            borderRadius: 3
          }}
        >
          <Typography fontWeight="bold" sx ={{fontSize : "18px"}}>
           Why AI Marked This Ticket as {selectedTicket.ai_resolution_status}
          </Typography>

          <Typography mt={1} sx ={{fontSize : "15px"}}>
            {selectedTicket.executive_summary}
          </Typography>
        </Alert>

        {/* STATUS COMPARISON */}
{/* 
        <Box
          display="grid"
          gridTemplateColumns="1fr 1fr"
          gap={2}
          mb={4}
        >
          <Paper
            sx={{
              p: 2,
              borderRadius: 3,
              textAlign: "center"
            }}
          >
            <Typography
              color="text.secondary"
            >
              Agent Status
            </Typography>

            <Chip
              sx={{ mt: 1 }}
              label={
                selectedTicket.agent_resolution_status
              }
              color="primary"
            />
          </Paper>

          <Paper
            sx={{
              p: 2,
              borderRadius: 3,
              textAlign: "center"
            }}
          >
            <Typography
              color="text.secondary"
            >
              AI Status
            </Typography>

            <Chip
              sx={{ mt: 1 }}
              label={
                selectedTicket.ai_resolution_status
              }
              color="warning"
            />
          </Paper>
        </Box> */}
     <Paper
  sx={{
    p: 2,
    mb: 3,
    borderRadius: 3,
    bgcolor: "#fafafa"
  }}
>
  <Stack
    direction="row"
    spacing={3}
    alignItems="center"
    justifyContent="center"
  >
    <Typography fontWeight={600}>
      Agent Status
    </Typography>

    <Chip
      label={selectedTicket.agent_resolution_status}
      color="primary"
      size="small"
    />

    <Typography
      color="text.secondary"
      fontWeight={700}
    >
      VS
    </Typography>

    <Typography fontWeight={600}>
      AI Status
    </Typography>

    <Chip
      label={selectedTicket.ai_resolution_status}
      color="warning"
      size="small"
    />
  </Stack>
</Paper>

        <Divider sx={{ mb: 3 }}>
         User & Agent Conversation
        </Divider>

        {/* CHAT VIEW */}

        

      <Box
  sx={{
    maxHeight: "40vh",
    overflowY: "auto",
    p: 1
  }}
>
  {conversationData.map((msg, index) => {
    const isAgent = msg.role === "Agent";

    return (
      <Box
        key={index}
        sx={{
          display: "flex",
          justifyContent: isAgent
            ? "flex-end"
            : "flex-start",
          mb: 2
        }}
      >
        <Box
          sx={{
            maxWidth: "75%"
          }}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "flex-end",
              gap: 1,
              flexDirection: isAgent
                ? "row-reverse"
                : "row"
            }}
          >
            <Avatar
              sx={{
                width: 32,
                height: 32,
                bgcolor: isAgent
                  ? "#1976d2"
                  : "#616161"
              }}
            >
              {isAgent ? (
                <SupportAgentIcon fontSize="small" />
              ) : (
                <PersonIcon fontSize="small" />
              )}
            </Avatar>

            <Paper
              elevation={1}
              sx={{
                px: 2,
                py: 1.5,
                borderRadius: 4,
                bgcolor: isAgent
                  ? "#DCF8C6"
                  : "#FFFFFF",
                border: "1px solid #e0e0e0",
                position: "relative"
              }}
            >
              <Typography
                variant="caption"
                sx={{
                  fontWeight: 700,
                  color: isAgent
                    ? "#1565c0"
                    : "#616161",
                  display: "block",
                  mb: 0.5
                }}
              >
                {msg.role}
              </Typography>

              <Typography variant="body2">
                {msg.message}
              </Typography>
            </Paper>
          </Box>
        </Box>
      </Box>
    );
  })}
</Box>

      </Box>
    )}
  </DialogContent>

  <DialogActions>
    <Button
      variant="outlined"
      onClick={() =>
        setOpenReviewDialog(false)
      }
    >
      Close
    </Button>
  </DialogActions>
</Dialog>
      
    </Box>
    
  );
}