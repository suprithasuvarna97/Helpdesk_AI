export const API_BASE_URL = "http://127.0.0.1:8000/api/v1";

export const API_HEADERS = {
  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
  "Origin": "https://ccda.healthit.gov",
  "Referer": "https://ccda.healthit.gov/scorecard/",
  "Accept": "application/json, text/plain, */*"
};

export const getGradeColor = (grade) => {
  if (!grade) return "bg-gray-100 text-gray-600 border-gray-300";
  const g = grade.toUpperCase();
  if (g.startsWith("A")) return "bg-emerald-50 text-emerald-700 border-emerald-200";
  if (g.startsWith("B")) return "bg-blue-50 text-blue-700 border-blue-200";
  if (g.startsWith("C")) return "bg-amber-50 text-amber-700 border-amber-200";
  return "bg-rose-50 text-rose-700 border-rose-200";
};

