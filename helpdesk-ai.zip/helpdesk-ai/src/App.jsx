import React, { useEffect, useState } from "react";

import {
  ThemeProvider,
  CssBaseline,
  Box,
  Drawer,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Button
} from "@mui/material";

import {
  Dashboard,
 Psychology,
  ChevronLeft,
  ChevronRight
} from "@mui/icons-material";

import { theme } from "./theme";

import { API_BASE_URL } from "./config";

import DashboardComponent from "./pages/Dashboard";
import AnalyticsTables from "./pages/AnalyticsTables";
import SupportAgentComponent from "./pages/SupportAgentList"
import tcsLogo from "./assets/tcs-logo.png";
import SupportAgentIcon from "@mui/icons-material/SupportAgent";

const drawerWidth = 260;
const collapsedDrawerWidth = 64;

export default function App() {
  const [navCollapsed, setNavCollapsed] =
    useState(false);

  const [activeTab, setActiveTab] =
    useState("dashboard");

  const [analysisData, setAnalysisData] =
    useState([]);

  const fetchAnalysis = async () => {
    try {
      const response = await fetch(
        `${API_BASE_URL}/analysis`
      );

      const data = await response.json();
     
      setAnalysisData(data || []);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchAnalysis();
  }, []);

  const navItems = [
    {
      id: "dashboard",
      label: "Helpdesk Dashboard",
      icon: <Dashboard />
    },

    {
      id: "analysis",
      label: "AI Analysis",
      icon: <Psychology />
    },

    {
      id: "agents",
      label: "Support Agents",
      icon: <SupportAgentIcon />
    }
  ];

  const currentWidth = navCollapsed
    ? collapsedDrawerWidth
    : drawerWidth;

  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />

      <Box sx={{ display: "flex" }}>

        {/* SIDEBAR */}

        <Drawer
          variant="permanent"
          sx={{
            width: currentWidth,

            flexShrink: 0,

            "& .MuiDrawer-paper": {
              width: currentWidth,
              boxSizing: "border-box",
              transition: "width 0.3s",
              overflowX: "hidden"
            }
          }}
        >
          <Box>

            <Box
              sx={{
                height: 64,
                bgcolor: "#0f172a",
                color: "#fff",

                display: "flex",

                alignItems: "center",

                justifyContent:
                  "space-between",

                px: 2
              }}
            >
               {!navCollapsed && (
                  <Box
                    component="img"
                    src={tcsLogo}
                    alt="TCS Logo"
                    sx={{
                      height: 40,
                      width: "auto",
                      objectFit: "contain",
                    }}
                  />
                )}

              <Button
                size="small"
                onClick={() =>
                  setNavCollapsed(
                    !navCollapsed
                  )
                }
                sx={{
                  color: "#fff",
                  minWidth: 0
                }}
              >
                {navCollapsed ? (
                  <ChevronRight />
                ) : (
                  <ChevronLeft />
                )}
              </Button>
            </Box>

            <List sx={{ p: 1 }}>

              {navItems.map((item) => (

                <ListItem
                  key={item.id}
                  disablePadding
                >
                  <ListItemButton
                    selected={
                      activeTab ===
                      item.id
                    }
                    onClick={() =>
                      setActiveTab(
                        item.id
                      )
                    }
                    sx={{
                      borderRadius: 2,

                      mb: 1,

                      "&.Mui-selected":
                        {
                          bgcolor:
                            "primary.main",

                          color:
                            "#fff"
                        }
                    }}
                  >
                    <ListItemIcon
                      sx={{
                        minWidth: 36
                      }}
                    >
                      {item.icon}
                    </ListItemIcon>

                    {!navCollapsed && (
                      <ListItemText
                        primary={
                          item.label
                        }
                      />
                    )}
                  </ListItemButton>
                </ListItem>

              ))}

            </List>
          </Box>
        </Drawer>

        {/* MAIN */}

        <Box
          component="main"
          sx={{
            flexGrow: 1,

            p: 4,

            width: {
              sm: `calc(100% - ${currentWidth}px)`
            },

            minHeight: "100vh",

            bgcolor:
              "background.default"
          }}
        >

          {activeTab ===
            "dashboard" && (
            <DashboardComponent
              analysisData={
                analysisData
              }
            />
          )}

          {activeTab ===
            "analysis" && (
            <AnalyticsTables
              analysisData={
                analysisData
              }
              refreshData={
                fetchAnalysis
              }
            />
          )}

             {activeTab ===
            "agents" && (
            <SupportAgentComponent
              analysisData={
                analysisData
              }
            />
          )}

        </Box>
      </Box>
    </ThemeProvider>
  );
}