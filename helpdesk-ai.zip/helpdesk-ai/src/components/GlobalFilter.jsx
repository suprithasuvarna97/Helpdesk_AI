import {
  Paper,
  Grid,
  TextField,
  MenuItem,
  Button,
  Typography,
  Box,
  Stack,
  Select,
  FormControl,
  InputLabel,
  Autocomplete,
} from "@mui/material";

import FilterAltIcon from "@mui/icons-material/FilterAlt";
import RestartAltIcon from "@mui/icons-material/RestartAlt";
import SearchIcon from "@mui/icons-material/Search";

import { useFilters } from "../context/FilterContext";
import { FilterAltOutlined } from "@mui/icons-material";


export default function GlobalFilter({ vendors, years, months,fileNames,
showVendor = true,
  showYear = true,
  showMonth = true,
  showFileName = true,
 }) {
  const { filters, setFilters } = useFilters();
  

  const handleChange = (field) => (event) => {
    setFilters((prev) => ({
      ...prev,
      [field]: event.target.value,
    }));
  };

  const handleReset = () => {
    setFilters({
      vendor: "All",
      year: "All",
      month: "All",
    });
  };

  return (
    <Paper
      elevation={2}
      sx={{
        p: 3,
        mb: 4,
        borderRadius: 4,
      }}
    >
      <Box
        display="flex"
        justifyContent="space-between"
        alignItems="center"
        mb={3}
      >
       
     
      </Box>
 
      <Grid container spacing={2} alignItems="center">
         {showVendor && (
        <Grid item xs={12} md={3}>
          <TextField
            select
            fullWidth
            size="small"
            sx = {{width :180}}
            label="Vendors"
            value={filters.vendor}
            onChange={handleChange("vendor")}
          >
           {vendors.map((vendor) => (
            <MenuItem key={vendor} value={vendor}>
                {vendor}
            </MenuItem>
            ))}
            </TextField>
            </Grid>)}

          {showFileName && (
 <Grid item xs={12} md={3}>
  <Autocomplete
    freeSolo
    size="small"
    options={fileNames.filter((f) => f !== "All")}
    value={filters.filename || null}
    inputValue={filters.filename || ""}
    onInputChange={(event, value) =>
      setFilters({
        ...filters,
        filename: value,
      })
    }
    renderInput={(params) => (
      <TextField
        {...params}
        label="Search File"
        placeholder="Search file..."
      />
    )}
    sx={{ width: 180 }}
  />
</Grid>)}

        
          {showYear && (
        <Grid item xs={12} md={3}>
          
        <FormControl size="small" sx={{ width: 180 }}>
        <InputLabel id="year-select-label">Year</InputLabel>

        <Select
            labelId="year-select-label"
            label="Year"
            value={filters.year}
            onChange={(e) =>
            setFilters({ ...filters, year: e.target.value })
            }
        >
            {years.map((year) => (
            <MenuItem key={year} value={year}>
                {year}
            </MenuItem>
            ))}
        </Select>
        </FormControl>
        </Grid>)}

    {showMonth && (
        <Grid item xs={12} md={3}>

              <FormControl size="small" sx={{ width: 180 }}>
        <InputLabel id="month-select-label">Month</InputLabel>

        <Select
            labelId="month-select-label"
            label="Month"
            value={filters.month}
                onChange={(e) =>
                    setFilters({ ...filters, month: e.target.value })
                }
        >
            {months.map((month) => (
            <MenuItem key={month} value={month}>
                {month}
            </MenuItem>
            ))}
        </Select>
        </FormControl>
     
    </Grid>)}

     {/* {showFileName && (
     <Grid item xs={12} md={3}>
      <FormControl size="small" sx={{ width: 250 }}>
        <InputLabel id="error-type-select-label">Error Type </InputLabel>

        <Select
            labelId="error-type-select-label"
            label="Error Type"
            value={filters.month}
                onChange={(e) =>
                    setFilters({ ...filters, month: e.target.value })
                }
        >
            {months.map((month) => (
            <MenuItem key={month} value={month}>
                {month}
            </MenuItem>
            ))}
        </Select>
        </FormControl>
    </Grid>)} */}


 <Grid item xs={12} md={3} sm = {6}>
 <Stack direction = "row" spacing={2}>
    <Button
      fullWidth
      variant="contained"
      startIcon={<RestartAltIcon />}
      onClick={handleReset}
      sx={{
        borderRadius: 2,
      }}
    >
      Reset
    </Button></Stack>
 
</Grid>
      </Grid>
    </Paper>
  );
}