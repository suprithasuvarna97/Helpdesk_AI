import { Card, CardContent, Typography, Box } from "@mui/material";

export default function StatsCard({
  title,
  value,
  icon,
  iconColor = "#1976d2",
  footer,
}) {
  return (
    <Card
      elevation={4}
      sx={{
        borderRadius: 3,
        overflow: "visible",
        position: "relative",
        pt: 6,
        mb:3,
        mt:3,
        width: "100%",
        height: "80%",

      }}
    >
      <Box
        sx={{
          position: "absolute",
          top: -32,
          left: 20,
          width: 72,
          height: 72,
          bgcolor: iconColor,
          color: "#fff",
          borderRadius: 3,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          boxShadow: 5,
        }}
      >
        {icon}
      </Box>

      <CardContent sx={{ pt: 4 }}>
        <Box display="flex" justifyContent="flex-end">
          <Box textAlign="right"
          >
            <Typography
              variant="body2"
              color="text.secondary"
            >
              {title}
            </Typography>

            <Typography
              variant="h4"
              fontWeight="bold"
            >
              {value}
            </Typography>
          </Box>
        </Box>

        {footer && (
          <>
            <Box
              sx={{
                borderTop: "1px solid",
                borderColor: "divider",
                mt: 2,
                pt: 2,
              }}
            >
              <Typography
                variant="body2"
                color="text.secondary"
              >
                {footer}
              </Typography>
            </Box>
          </>
        )}
      </CardContent>
    </Card>
  );
}