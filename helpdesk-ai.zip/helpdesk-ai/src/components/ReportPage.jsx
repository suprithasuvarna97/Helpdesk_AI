
import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

import {
  Box,
  Typography,
  Card,
  CardContent,
  Paper,
  Chip,
  LinearProgress,
  CircularProgress,
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Table,
  TableHead,
  TableRow,
  TableCell,
  TableBody,
  TableContainer,
  Avatar,
} from "@mui/material";

import PersonIcon from "@mui/icons-material/Person";
import DescriptionIcon from "@mui/icons-material/Description";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";

import { API_BASE_URL } from "../config";

export default function ReportPage() {
  const { fileId } = useParams();

  const [reportData, setReportData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReport();
  }, [fileId]);

  const loadReport = async () => {
    try {
 

      const response = await fetch(
        `${API_BASE_URL}/report/${fileId}`
      );

      const data = await response.json();

      setReportData(data.extracted_report);
      

      //setReportData(mockData);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <Box
        sx={{
          minHeight: "100vh",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <CircularProgress />
      </Box>
    );
  }

  const patient = reportData.patient;
  const documentInfo = reportData.document;
  const sections = reportData.allSections || {};

  const missingSections = Object.entries(sections)
    .filter(([_, section]) => {
      return (
        !section.tableData ||
        section.tableData.length === 0 ||
        section.tableData[0]?.Description ===
          "No Information Available"
      );
    })
    .map(([key]) => key.replaceAll("_", " "));

 const totalSections = Object.keys(sections || {}).length;

  const completedSections =
    totalSections - missingSections.length;

  const completeness =
    totalSections > 0
      ? Math.round(
          (completedSections / totalSections) * 100
        )
      : 0;

  // const vitalsCount = 
  //   sections?.vital_signs?.tableData?.length || 0;
 const completedSectionNames = Object.entries(sections)
  .filter(([_, section]) => {
    return (
      section?.tableData &&
      section.tableData.length > 0 &&
      section.tableData[0]?.Description !==
        "No Information Available"
    );
  })
  .map(([key, section]) =>
    section?.title ||
    key.replaceAll("_", " ")
  );

  return (
    <Box
      sx={{
        bgcolor: "#f4f7fb",
        minHeight: "100vh",
        p: 4,
      }}
    >
      <Box
        sx={{
          width: "100%",
          maxWidth: "1800px",
          mx: "auto",
        }}
      >
        {/* HEADER */}

        <Paper
          elevation={5}
          sx={{
            p: 4,
            mb: 4,
            borderRadius: 4,
            background:
              "linear-gradient(135deg,#1976d2,#42a5f5)",
            color: "#fff",
          }}
        >
          <Typography
            variant="h4"
            fontWeight="700"
          >
            CCDA Clinical Report
          </Typography>

          <Typography sx={{ mt: 1 }}>
            {documentInfo.title}
          </Typography>

          <Typography sx={{ mt: 1 }}>
            File ID : {fileId}
          </Typography>

          {/* <Typography sx={{ mt: 1 }}>
            Effective Time :{" "}
            {documentInfo.effectiveTime}
          </Typography> */}
        </Paper>

          {/* PATIENT */}

        <Card
          elevation={3}
          sx={{
            mb: 4,
            borderRadius: 4,
          }}
        >
          <CardContent>
            <Box
              display="flex"
              alignItems="center"
              gap={2}
              mb={2}
            >
              <Avatar
                sx={{
                  bgcolor: "#1976d2",
                }}
              >
                <PersonIcon />
              </Avatar>

              <Typography
                variant="h5"
                fontWeight={700}
              >
                Patient Information
              </Typography>
            </Box>

            <Typography>
              <b>Name :</b>{" "}
              {patient.firstName}{" "}
              {patient.lastName}
            </Typography>

            <Typography>
              <b>MRN :</b> {patient.id}
            </Typography>

            <Typography>
              <b>Gender :</b> {patient.gender}
            </Typography>

            <Typography>
              <b>Date Of Birth :</b>{" "}
              {patient.birthDate}
            </Typography>

            <Typography>
              <b>Phone :</b> {patient.phone}
            </Typography>

            <Typography>
              <b>Address :</b>{" "}
              {patient.address?.street},{" "}
              {patient.address?.city},{" "}
              {patient.address?.state},{" "}
              {patient.address?.postalCode}
            </Typography>
          </CardContent>
        </Card>


        {/* SUMMARY */}

        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: {
              xs: "1fr",
              sm: "repeat(2,1fr)",
              md: "repeat(4,1fr)",
            },
            gap: 3,
            mb: 4,
          }}
        >
          <SummaryCard
            label="Total Sections"
            value={totalSections}
          />

          <SummaryCard
            label="Populated Sections"
            value={completedSections}
          />

          <SummaryCard
            label="Missing Sections"
            value={missingSections.length}
          />

          <SummaryCard
            label="Completeness"
            value={`${completeness}%`}
          />
        </Box>

      
        {/* DOCUMENT */}

        {/* <Card
          elevation={3}
          sx={{
            mb: 4,
            borderRadius: 4,
          }}
        >
          <CardContent>
            <Box
              display="flex"
              alignItems="center"
              gap={2}
              mb={2}
            >
              <Avatar
                sx={{
                  bgcolor: "#7b1fa2",
                }}
              >
                <DescriptionIcon />
              </Avatar>

              <Typography
                variant="h5"
                fontWeight={700}
              >
                Document Information
              </Typography>
            </Box>

            <Typography>
              <b>Title :</b>{" "}
              {documentInfo.title}
            </Typography>

            <Typography>
              <b>Effective Time :</b>{" "}
              {documentInfo.effectiveTime}
            </Typography>
          </CardContent>
        </Card> */}

        {/* COMPLETENESS */}

        <Card
          elevation={3}
          sx={{
            mb: 4,
            borderRadius: 4,
          }}
        >
          <CardContent>
            <Typography
              variant="h5"
              fontWeight={700}
              gutterBottom
            >
              CCDA Completeness Score
            </Typography>

            <Typography
              variant="h2"
              color="primary"
              fontWeight="bold"
            >
              {completeness}%
            </Typography>

            <LinearProgress
              variant="determinate"
              value={completeness}
              sx={{
                mt: 3,
                height: 14,
                borderRadius: 10,
              }}
            />
          </CardContent>
        </Card>

        {/* MISSING */}

        <Card
          elevation={3}
          sx={{
            mb: 4,
            borderRadius: 4,
          }}
        >
          <CardContent>
            <Box
              display="flex"
              alignItems="center"
              gap={2}
              mb={2}
            >
              <Avatar
                sx={{
                  bgcolor: "#ed6c02",
                }}
              >
                <WarningAmberIcon />
              </Avatar>

              <Typography
                variant="h5"
                fontWeight={700}
              >
               Incomplete Sections
              </Typography>
            </Box>

            <Box
              sx={{
                mt:3,
                display: "flex",
                flexWrap: "wrap",
                gap: 2,
              }}
            >
              {missingSections.map((item) => (
                <Chip
                  key={item}
                  label={item}
                  color="error"
                />
              ))}
            </Box>
          </CardContent>
        </Card>
        {/* Complete sections */}
        <Card
  elevation={3}
  sx={{
    mb: 4,
    borderRadius: 4,
  }}
>
  <CardContent>
    <Box
      display="flex"
      alignItems="center"
      gap={2}
      mb={2}
    >
      <Avatar
        sx={{
          bgcolor: "#2e7d32",
        }}
      >
        ✅
      </Avatar>

      <Typography
        variant="h5"
        fontWeight={700}
      >
      Available Sections
      </Typography>
    </Box>

    <Box
      sx={{
        mt: 3,
        display: "flex",
        flexWrap: "wrap",
        gap: 2,
      }}
    >
      {completedSectionNames.map((item) => (
        <Chip
          key={item}
          label={item}
          color="success"
          variant="filled"
        />
      ))}
    </Box>
  </CardContent>
</Card>

        {/* DYNAMIC SECTIONS */}

        {Object.entries(sections).map(
          ([key, section]) => (
            <Accordion
              key={key}
              sx={{
                mb: 2,
                borderRadius: "12px !important",
              }}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
              >
                <Typography
                  fontWeight={700}
                >
                  {section.title}
                </Typography>
              </AccordionSummary>

              <AccordionDetails>
                {section.tableData &&
                section.tableData.length > 0 ? (
                  <TableContainer
                    component={Paper}
                  >
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          {Object.keys(
                            section.tableData[0]
                          ).map((column) => (
                            <TableCell
                              key={column}
                            >
                              <b>{column}</b>
                            </TableCell>
                          ))}
                        </TableRow>
                      </TableHead>

                      <TableBody>
                        {section.tableData.map(
                          (row, index) => (
                            <TableRow
                              key={index}
                            >
                              {Object.values(
                                row
                              ).map(
                                (
                                  value,
                                  colIndex
                                ) => (
                                  <TableCell
                                    key={
                                      colIndex
                                    }
                                  >
                                    {String(
                                      value ??
                                        "-"
                                    )}
                                  </TableCell>
                                )
                              )}
                            </TableRow>
                          )
                        )}
                      </TableBody>
                    </Table>
                  </TableContainer>
                ) : (
                  <Typography>
                    No Data Available
                  </Typography>
                )}
              </AccordionDetails>
            </Accordion>
          )
        )}
      </Box>
    </Box>
  );
}

function SummaryCard({
  label,
  value,
}) {
  return (
    <Card
      elevation={3}
      sx={{
        borderRadius: 4,
      }}
    >
      <CardContent>
        <Typography color="text.secondary">
          {label}
        </Typography>

        <Typography
          variant="h3"
          fontWeight={700}
        >
          {value}
        </Typography>
      </CardContent>
    </Card>
  );
}

/*
==========================================
TEMP MOCK DATA
Replace with API response later
==========================================
*/

// const mockData = {
//   patient: {
//     id: "mrn2B0D2963-2961-494C-A1D4-2E5F1A3B8B71",
//     firstName: "FNAME420",
//     lastName: "LNAME457",
//     gender: "Male",
//     birthDate: "19840101",
//     phone: "5555555555",
//     address: {
//       city: "city120",
//       state: "PA",
//       street: "street name 222",
//       postalCode: "42648",
//       country: "US",
//     },
//   },

//   document: {
//     title:
//       "Continuity of Care Document (CCD)",
//     effectiveTime:
//       "20230216082126-0500",
//   },

//   allSections: {
//     problems: {
//       title: "Problems",
//       tableData: [
//         {
//           Date: "07/11/2013",
//           Problem:
//             "Elevated blood-pressure reading",
//         },
//       ],
//     },

//     assessments: {
//       title: "Assessments",
//       tableData: [
//         {
//           Code: "Z13.9",
//           Date: "02/02/2023",
//           Description:
//             "Encounter for screening",
//           Provider:
//             "Jeffrey Yount II, PA-C",
//         },
//       ],
//     },

//     medications: {
//       title: "Medications",
//       tableData: [
//         {
//           Date: "07/18/2013",
//           Qnty: "30tabs",
//           Provider:
//             "Jessica B Pagana-Defazio, DO",
//         },
//       ],
//     },

//     vital_signs: {
//       title: "Vital Signs",
//       tableData: [
//         {
//           Date: "07/27/2022",
//           Result: "170 mmHg",
//         },
//         {
//           Vital: "98.0 °F",
//         },
//       ],
//     },

//     immunizations: {
//       title: "Immunizations",
//       tableData: [
//         {
//           Description:
//             "No Information Available",
//         },
//       ],
//     },

//     encounters: {
//       title: "Encounters",
//       tableData: [
//         {
//           Description:
//             "No Information Available",
//         },
//       ],
//     },
//   },
// };
const mockData =
{
        "patient": {
          "id": "mrn2B0D2963-2961-494C-A1D4-2E5F1A3B8B71",
          "race": null,
          "email": null,
          "phone": "5555555555",
          "gender": "Male",
          "address": {
            "city": "city120",
            "state": "PA",
            "street": "street name 222",
            "country": "US",
            "postalCode": "42648"
          },
          "lastName": "LNAME457",
          "birthDate": "19840101",
          "ethnicity": null,
          "firstName": "FNAME420",
          "middleName": null,
          "maritalStatus": null
        },
        "results": {
          "title": "Results",
          "tableData": [
            {
              "Description": "No Information Available"
            }
          ],
          "structuredData": []
        },
        "document": {
          "title": "Continuity of Care Document (CCD)",
          "effectiveTime": "20230216082126-0500"
        },
        "problems": {

        },
        "allergies": {

        },
        "encounters": {
          "title": "Encounters",
          "tableData": [
            {
              "Description": "No Information Available"
            }
          ],
          "structuredData": []
        },
        "procedures": {
          "title": "Procedures",
          "tableData": [
            {
              "Description": "No Information Available"
            }
          ],
          "structuredData": []
        },
        "allSections": {
          "results": {
            "title": "Results",
            "tableData": [
              {
                "Description": "No Information Available"
              }
            ],
            "structuredData": []
          },
          "problems": {
            "title": "Problems",
            "tableData": [
              {
                "Date": "Onset: 07/11/2013",
                "Provider": null,
                "Active Problems": ""
              }
            ],
            "structuredData": [
              {
                "code": "371622005",
                "codeSystem": "SNOMED CT",
                "displayName": "Elevated blood-pressure reading without diagnosis of hypertension"
              }
            ]
          },
          "referrals": {
            "title": "Referrals",
            "tableData": [
              {
                "Description": "No Information Available"
              }
            ],
            "structuredData": []
          },
          "encounters": {
            "title": "Encounters",
            "tableData": [
              {
                "Description": "No Information Available"
              }
            ],
            "structuredData": []
          },
          "procedures": {
            "title": "Procedures",
            "tableData": [
              {
                "Description": "No Information Available"
              }
            ],
            "structuredData": []
          },
          "assessments": {
            "title": "Assessments",
            "tableData": [
              {
                "Code": "Z13.9",
                "Date": "02/02/2023",
                "Provider": "Jeffrey Yount II, PA-C",
                "Description": "Encounter for screening, unspecified"
              }
            ],
            "structuredData": []
          },
          "medications": {
            "title": "Medications",
            "tableData": [
              {
                "SIG": "",
                "Date": "07/18/2013",
                "Qnty": "30tabs",
                "Indications": null,
                "Ordering Provider": "Jessica B Pagana-Defazio, DO",
                "Active Medications": ""
              },
              {
                "SIG": "",
                "Date": "07/11/2013",
                "Qnty": "42tabs",
                "Indications": null,
                "Ordering Provider": "Jessica B Pagana-Defazio, DO",
                "Active Medications": ""
              }
            ],
            "structuredData": []
          },
          "vital_signs": {
            "title": "Vital Signs",
            "tableData": [
              {
                "Date": "07/27/2022  9:17am",
                "Vital": "",
                "Result": "170 mmHg",
                "Comment": null
              },
              {
                "Date": "",
                "Vital": "110 mmHg",
                "Result": null
              },
              {
                "Date": "",
                "Vital": "98.0 °F",
                "Result": null
              },
              {
                "Date": "",
                "Vital": "65 /min",
                "Result": null
              },
              {
                "Date": "",
                "Vital": "20 /min",
                "Result": null
              },
              {
                "Date": "",
                "Vital": "461.00 lb",
                "Result": null
              },
              {
                "Date": "",
                "Vital": "209.110 kg",
                "Result": null
              },
              {
                "Date": "",
                "Vital": "71 inches",
                "Result": ""
              },
              {
                "Date": "",
                "Vital": "64.3 kg/m2",
                "Result": null
              },
              {
                "Date": "",
                "Vital": "172 lb",
                "Result": null
              },
              {
                "Date": "07/11/2013 11:47am",
                "Vital": "",
                "Result": "160 mmHg",
                "Comment": null
              },
              {
                "Date": "",
                "Vital": "100 mmHg",
                "Result": null
              },
              {
                "Date": "",
                "Vital": "97.9 °F",
                "Result": null
              },
              {
                "Date": "",
                "Vital": "72 /min",
                "Result": null
              },
              {
                "Date": "",
                "Vital": "16 /min",
                "Result": null
              },
              {
                "Date": "",
                "Vital": "71 inches",
                "Result": null
              }
            ],
            "structuredData": [
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              },
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              }
            ]
          },
          "immunizations": {
            "title": "Immunizations",
            "tableData": [
              {
                "Description": "No Information Available"
              }
            ],
            "structuredData": []
          },
          "mental_status": {
            "title": "Mental Status",
            "tableData": [
              {
                "Description": "No Information Available"
              }
            ],
            "structuredData": []
          },
          "social_history": {
            "title": "Social History",
            "tableData": [
              {
                "Date": null,
                "Type": "Birth Sex",
                "Comments": null,
                "Description": "Unknown"
              }
            ],
            "structuredData": [
              {
                "code": null,
                "codeSystem": null,
                "displayName": null
              }
            ]
          },
          "medical_devices": {
            "title": "Medical Devices",
            "tableData": [
              {
                "Description": "No Information Available"
              }
            ],
            "structuredData": []
          },
          "functional_status": {
            "title": "Functional Status",
            "tableData": [
              {
                "Description": "No Information Available"
              }
            ],
            "structuredData": []
          },
          "plan_of_treatment": {
            "title": "Plan of Treatment",
            "tableData": [],
            "structuredData": []
          },
          "allergies_and_adverse_reactions": {
            "title": "Allergies and adverse reactions",
            "tableData": [
              {
                "Description": "No Information Available"
              }
            ],
            "structuredData": []
          }
        },
        "medications": {
          "title": "Medications",
          "tableData": [
            {
              "SIG": "",
              "Date": "07/18/2013",
              "Qnty": "30tabs",
              "Indications": null,
              "Ordering Provider": "Jessica B Pagana-Defazio, DO",
              "Active Medications": ""
            },
            {
              "SIG": "",
              "Date": "07/11/2013",
              "Qnty": "42tabs",
              "Indications": null,
              "Ordering Provider": "Jessica B Pagana-Defazio, DO",
              "Active Medications": ""
            }
          ],
          "structuredData": []
        },
        "immunizations": {
          "title": "Immunizations",
          "tableData": [
            {
              "Description": "No Information Available"
            }
          ],
          "structuredData": []
        }
      }