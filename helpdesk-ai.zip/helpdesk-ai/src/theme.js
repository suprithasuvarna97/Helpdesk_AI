import { createTheme } from "@mui/material/styles";

export const theme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#022d58", // Tech Blue
      light: "#42a5f5",
      dark: "#1565c0",
    },
    secondary: {
      main: "#9c27b0",
    },
    success: {
      main: "#2e7d32", // Emerald Pass Green
      light: "#e8f5e9",
    },
    error: {
      main: "#d32f2f", // Crimson Fail Red
      light: "#ffebee",
    },
    warning: {
      main: "#ed6c02", // Amber Vocab Warning
      light: "#fff3e0",
    },
    background: {
      default: "#f4f6f9",
      paper: "#ffffff",
    },
    text: {
      primary: "#1e293b",
      secondary: "#64748b",
    },
  },
  typography: {
    fontFamily: '"Inter", "Roboto", "Helvetica", "Arial", sans-serif',
    button: {
      textTransform: "none",
      fontWeight: 600,
    },
  },
});

export const getGradeStyles = (grade) => {
  if (!grade) return { color: "#64748b", bg: "#f1f5f9", border: "#cbd5e1" };
  const g = grade.toUpperCase();
  if (g.startsWith("A")) return { color: "#1b5e20", bg: "#e8f5e9", border: "#c8e6c9" };
  if (g.startsWith("B")) return { color: "#0d47a1", bg: "#e3f2fd", border: "#bbdefb" };
  if (g.startsWith("C")) return { color: "#e65100", bg: "#fff3e0", border: "#ffe0b2" };
  return { color: "#b71c1c", bg: "#ffebee", border: "#ffcdd2" };
};


